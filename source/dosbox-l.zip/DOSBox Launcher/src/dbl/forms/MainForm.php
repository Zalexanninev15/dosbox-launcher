<?php
namespace dbl\forms;

use std, gui, framework, dbl;
use php\gui\UXDesktop;


class MainForm extends AbstractForm
{


    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        execute("cmd /c start dosbox.bat");
    }

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {
        open('./DOSBox/Profile1.conf');
    }

    /**
     * @event button7.action 
     */
    function doButton7Action(UXEvent $e = null)
    {    
        open('./DOSBox/Profile2.conf');
    }

    /**
     * @event button8.action 
     */
    function doButton8Action(UXEvent $e = null)
    {    
        open('./DOSBox/Profile3.conf');
    }

    /**
     * @event button9.action 
     */
    function doButton9Action(UXEvent $e = null)
    {    
        $desktop = new UXDesktop();
        $desktop->edit('dosbox.bat');
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        app()->shutdown();
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        execute("cmd /c start copy1.bat");
    }


    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        execute("cmd /c start copy2.bat");
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
        execute("cmd /c start copy3.bat");
    }



}
