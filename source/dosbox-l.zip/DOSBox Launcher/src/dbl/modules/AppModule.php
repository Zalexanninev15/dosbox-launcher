<?php
namespace dbl\modules;

use std, gui, framework, dbl;


class AppModule extends AbstractModule
{

}